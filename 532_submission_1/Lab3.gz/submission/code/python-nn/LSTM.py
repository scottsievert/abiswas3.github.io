import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import re;
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.ensemble import RandomForestClassifier


from keras.preprocessing import sequence
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.recurrent import GRU
from keras.datasets import imdb


def main():
    max_features = 20000
    batch_size = 32
    # Keras has the IMDB review data set
    # test_split denotes the ratio to split the data in test and train
    # Hence test size = 0.2 * 25000 = 5000
    # Hence train size = 20000
    # nb words is the number of words in the vocabulary
    # Each word will be mapped to a number from 1 to 20000
    (X_train,y_train),(X_test,y_test) = imdb.load_data(nb_words=max_features,\
                                                        test_split=0.2)

    #Verify the sizes here
    print "Lengths of the training data"
    print len(X_train)
    print len(y_train)

    #Pad the data
    #Each review can be of arbitrary length
    #We force each review to be of size 'maxlen'
    #This is needed to fix the size of each sequence in the LSTM
    #Reviews with size > maxlen are cut, others are padded with '0' to the same size
    maxlen = 100
    X_train = sequence.pad_sequences(X_train,maxlen=maxlen)
    X_test = sequence.pad_sequences(X_test,maxlen=maxlen)

    #Verify that the length is still the same
    print "Lengths of the training data"
    print len(X_train)
    print len(y_train)

    #Build the LSTM/GRU model using Keras
    model = Sequential()
    #An embedding is needed to convert each positive integer into a
    #dense vector of fixed size, which is then fed to the network
    #e.g. suppose I want to represent each number by a 2-d vector
    #4 -> [0.25,0.1]
    #This is needed for RNN
    #output is a 128 dimensional vector.
    model.add(Embedding(max_features, 128, input_length=maxlen))
    #Create a GRU/LSTM
    #128 specifies the dimension of the output
    model.add(GRU(128))
    #Dropout determines the probability of a node being dropped out
    #This helps to faster train the data as well as prevent overfitting
    model.add(Dropout(0.5))
    #Add one single perceptron on top which will predict 0 or 1
    #based on the inputs from all timestamps
    model.add(Dense(1))
    #Set activation to use sigmoid function for this layer
    model.add(Activation('sigmoid'))

    #Set Loss function and compile model
    #We are using adam which is an optimized sgd
    #link to paper http://arxiv.org/pdf/1412.6980v8.pdf
    #try using 'sgd' instead
    #loss is crossentropy = y*ln(o) + (1-y)*ln(1-o)
    model.compile(loss='binary_crossentropy',\
                  optimizer='adam',\
                  class_mode="binary")

    print "Training"
    #Train the model.No of epochs is set to 3 to reduce time to train
    #try increasing it and see effect on train time and accuracy
    #we are checking accuracy on test data after each epoch
    #see how this varies
    model.fit(X_train, y_train, batch_size=batch_size, nb_epoch=3,\
              validation_data=(X_test, y_test), show_accuracy=True)
    print "Testing"
    #Final accuracy on test data
    score,accuracy = model.evaluate(X_test, y_test,\
                                    batch_size=batch_size,\
                                    show_accuracy=True)
    print("Test Accuracy:",accuracy)
    print("Test Score:",score)
    return

if __name__ == "__main__":
    main()
