import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import re;
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.ensemble import RandomForestClassifier


from keras.preprocessing import sequence
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.recurrent import GRU
from keras.datasets import imdb
from keras.optimizers import SGD


def main():
    X_train = np.zeros((4, 2), dtype='uint8')
    y_train = np.zeros(4, dtype='uint8')
    X_test = np.zeros((4, 2), dtype='uint8')
    y_test = np.zeros(4, dtype='uint8')
    #Build ANN for XOR gate
    X_train = np.asarray([[0,0],[0,1],[1,0],[1,1]])
    y_train = np.asarray([0,1,1,0])
    X_test = np.asarray([[0,0],[1,0],[1,1]])
    y_test = np.asarray([0,1,0])
    #Build the ANN model using Keras
    model = Sequential()
    #Add 2 perceptrons to the first layer
    #i.e. 2 inputs
    #init defines the probability distribution from which the 
    #initial weights are taken. glorot_uniform is gaussian initialization
    #try uniform
    model.add(Dense(2, input_dim=2, init='glorot_uniform'))
    model.add(Activation('sigmoid'))
    #Add 1 perceptron to the second layer
    model.add(Dense(1, init='uniform'))
    model.add(Activation('sigmoid'))

    #sgd is used for optimization. We add a momentum term to keep
    #the waits moving in the same direction when gradients are small
    sgd = SGD(lr=0.1, decay=1e-6, momentum=0.9, nesterov=True)
    #Set Loss function and compile model
    #Using mean_squared error as the loss
    #which is the same as LS loss
    #try using 'binary_crossengropy' instead
    #which is crossentropy = y*ln(o) + (1-y)*ln(1-o)
    model.compile(loss='mean_squared_error',\
                  optimizer=sgd,\
                  class_mode="binary")

    print "Training"
    #Train the model.No of epochs is set to 3 to reduce time to train
    #try increasing it and see effect on train time and accuracy
    #we are checking accuracy on test data after each epoch
    #see how this varies
    model.fit((X_train), (y_train),batch_size=4, nb_epoch=10000,\
              validation_data=(X_test,y_test), show_accuracy=True)
    print "Testing"
    #Final accuracy on test data
    score,accuracy = model.evaluate(X_test, y_test,\
                                    batch_size=4,\
                                    show_accuracy=True)
    print model.predict(X_train)
    return

if __name__ == "__main__":
    main()
