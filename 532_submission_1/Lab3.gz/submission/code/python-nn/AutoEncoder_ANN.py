import numpy as np
import theano

from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.recurrent import GRU
from keras.datasets import imdb
from keras.optimizers import SGD


def main():
    #Build ANN for XOR gate
    X = np.asarray([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    y = X
    #Build the ANN model using Keras
    model = Sequential()
    #Add 2 perceptrons to the first layer
    #i.e. 2 inputs
    #init defines the probability distribution from which the 
    #initial weights are taken. glorot_uniform is gaussian initialization
    #try uniform
    model.add(Dense(2, input_dim=4, init='glorot_uniform'))
    #This intermediate layer represents a 2-d encoding for the input X
    #will print outputs of this at the end of the code
    l1 = Activation('sigmoid')
    model.add(l1)
    #Output layer added
    model.add(Dense(4,init='glorot_uniform'))
    model.add(Activation('sigmoid'))
    #sgd is used for optimization. We add a momentum term to keep
    #the waits moving in the same direction when gradients are small
    sgd = SGD(lr=0.1, decay=1e-6, momentum=0.9, nesterov=True)
    #Set Loss function and compile model
    #Using mean_squared error as the loss
    #which is the same as LS loss
    #try using 'binary_crossengropy' instead
    #which is crossentropy = y*ln(o) + (1-y)*ln(1-o)
    model.compile(loss='mean_squared_error',\
                  optimizer=sgd,\
                  class_mode="binary")

    print "Training"
    #Train the model.No of epochs is set to 3 to reduce time to train
    #try increasing it and see effect on train time and accuracy
    #we are checking accuracy on test data after each epoch
    #see how this varies
    model.fit((X), (y),batch_size=4, nb_epoch=10000,\
              validation_data=(X,y), show_accuracy=True)
    print "Testing"
    print model.predict(X)
    print "Intermediate layer of 2 perceptrons"
    print "Notice they have a binary encoding"
    l1f = theano.function([model.get_input(train=False)], l1.get_output(train=False))
    print l1f(np.float32(X))
    return

if __name__ == "__main__":
    main()
