import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import re;
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier

def process_review_to_words(raw_review):
    #Processes a raw review
    # Step 1 remove the html
    html_removed = BeautifulSoup(raw_review,"html.parser");

    # Step 2 remove the punctuation
    # We should improve here
    no_punct = re.sub("[^a-zA-Z]",
                        " ",
                       html_removed.getText());

    #Step 3 tokenize to words
    in_words = no_punct.split(" ");

    #Step 4 Convert to lowercase
    lower_words = [word.lower() for word in in_words]

    #Step 5 Remove stop words
    sw = set(stopwords.words("English"))
    final_words = [w for w in lower_words if not w in sw]

    #Step 6 join the meaningful words
    joined = " ".join(final_words)

    return joined

def preprocessor(train):
    #Clean all reviews
    num_reviews = train["review"].size
    clean_reviews = []
    for i in xrange(0,num_reviews):
        if(i%1000 == 0):
            print "Processing %d of %d"% (i+1,num_reviews)
        clean_reviews.append(process_review_to_words(train["review"][i]))
    #vectorize the reviews
    vectorizer = CountVectorizer(analyzer = "word",\
                                 tokenizer = None,\
                                 preprocessor = None,\
                                 stop_words = None,\
                                 max_features = 5000)
    #fit_transform will fit a model to data
    #which will consist of 5000 words
    #each vector is a 1x5000 vector of counts
    #So for each movie review we get one such vector
    train_data = vectorizer.fit_transform(clean_reviews)
    train_data = train_data.toarray()
    return train_data

def main():
    #Read The training data
    train = pd.read_csv("../data/labeledTrainData.tsv", header=0, \
                                delimiter="\t", quoting=3)
    #clean and convert data to vector
    print "Preprocessing......"
    trainData = preprocessor(train)
    return

if __name__ == "__main__":
    main()
