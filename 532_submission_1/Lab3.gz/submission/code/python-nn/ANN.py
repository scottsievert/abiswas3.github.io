import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import re;
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.ensemble import RandomForestClassifier


from keras.preprocessing import sequence
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.recurrent import GRU
from keras.datasets import imdb
from keras.optimizers import SGD


def main():
    max_features = 20000
    batch_size = 32
    # Keras has the IMDB review data set
    # test_split denotes the ratio to split the data in test and train
    # Hence test size = 0.2 * 25000 = 5000
    # Hence train size = 20000
    # nb words is the number of words in the vocabulary
    # Each word will be mapped to a number from 1 to 20000
    (X_train,y_train),(X_test,y_test) = imdb.load_data(nb_words=max_features,\
                                                        test_split=0.2)

    #Verify the sizes here
    print "Lengths of the training data"
    print len(X_train)
    print len(y_train)

    #Pad the data
    #Each review can be of arbitrary length
    #We force each review to be of size 'maxlen'
    #This is needed to fix the size of each sequence in the LSTM
    #Reviews with size > maxlen are cut, others are padded with '0' to the same size
    maxlen = 100
    X_train = sequence.pad_sequences(X_train,maxlen=maxlen)
    X_test = sequence.pad_sequences(X_test,maxlen=maxlen)
    #Verify that the length is still the same
    print "Lengths of the training data"
    print len(X_train)
    print len(y_train)

    #Build the ANN model using Keras
    model = Sequential()
    # Dense(64) is a fully-connected layer with 64 hidden units.
    # In the first layer we need to specify input dimension
    # Here it is of dimension 'maxlen'
    model.add(Dense(64, input_dim=maxlen, init='uniform'))
    # Activation function is tanh
    model.add(Activation('tanh'))
    #Dropout determines the probability of a node being dropped out
    #This helps to faster train the data as well as prevent overfitting
    model.add(Dropout(0.5))
    #Add the second layer
    model.add(Dense(64, init='uniform'))
    # Activation function is tanh
    model.add(Activation('tanh'))
    #Dropout determines the probability of a node being dropped out
    #This helps to faster train the data as well as prevent overfitting
    model.add(Dropout(0.5))
    #Add one single perceptron on top which will predict 0 or 1
    #based on the inputs from all timestamps
    model.add(Dense(1))
    #Set activation to use sigmoid function for this layer
    model.add(Activation('sigmoid'))

    #Set Loss function and compile model
    #Using mean_squared error as the loss 
    #which is the same as LS loss
    #try using 'binary_crossengropy' instead
    #which is crossentropy = y*ln(o) + (1-y)*ln(1-o)
    sgd = SGD(lr=0.1, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(loss='mean_squared_error',\
                  optimizer=sgd,\
                  class_mode="binary")

    print "Training"
    #Train the model.No of epochs is set to 3 to reduce time to train
    #try increasing it and see effect on train time and accuracy
    #we are checking accuracy on test data after each epoch
    #see how this varies
    model.fit(X_train, y_train, batch_size=batch_size, nb_epoch=3,\
              validation_data=(X_test, y_test), show_accuracy=True)
    print "Testing"
    #Final accuracy on test data
    score,accuracy = model.evaluate(X_test, y_test,\
                                    batch_size=batch_size,\
                                    show_accuracy=True)
    print("Test Accuracy:",accuracy)
    print("Test Score:",score)
    return

if __name__ == "__main__":
    main()
