%SVM Classifier
 
clear;
load 'sentimentData'
load 'labels';
At = data(1:20000,1:500);    
bt = labels(1:20000);
Ah = data(20001:25000,1:500);
bh = labels(20001:25000);
 
clear data;
clear labels;
 
m = size(At, 1);
offset = ones(m, 1);
At = [At offset];
 
clear offset;
 
w_init = zeros(501,1);
max_iter = 200;
lambda = 0.1;
gamma = 0.003;
for i = 1: max_iter
    gradient = 0;
    for j = 1:m
      gradient = gradient - At(j, :)'*bt(j)*(bt(j)*At(j, :)*w_init < 1);
    end
    gradient = gradient + 2*lambda*w_init;
    
    w_new = w_init  - gamma*gradient;
    w_init = w_new;
end
 
l = size(Ah, 1);
offset = ones(l, 1);
Ah = [Ah offset];
 
 
b_predicted = (Ah*w_new);
for i = 1:5000
    if b_predicted(i,:) <= 0
        b_predicted(i,:) = 0;
    else
        b_predicted(i,:) = 1;
    end
end
avg_err = norm(b_predicted - bh,1)/5000

