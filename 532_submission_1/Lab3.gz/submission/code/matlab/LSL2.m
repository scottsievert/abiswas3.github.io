% L2 Regularization
clear all;
 
% load the data matrix, i.e. A
A = load('sentimentData');
A = A.data;
 
% load the labels, i.e. b 
b = load('labels');
b = b.labels;
    
A_train = A(1:20000,1:5000);
b_train = b(1:20000, :);
 
A_holdout = A(20001:25000,1:5000); 
b_holdout = b(20001:25000,:); 
 
clear A;
clear b;
 
% Solve the least squares problem using training data
X = inv((A_train' * A_train) + (2)*eye(5000)) * (A_train' * b_train);
    
% predict labels of hold-out faces with weights from training set 
b_predicted = (A_holdout*X); % +1 if >0 and 0 if <0.
 
for i = 1:5000
    if b_predicted(i,:) <= 0
        b_predicted(i,:) = 0;
    else
        b_predicted(i,:) = 1;
    end
end
 
avg_err  = norm((b_holdout-b_predicted),1)/5000

