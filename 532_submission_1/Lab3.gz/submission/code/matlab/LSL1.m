function main()
    clear all;
    load 'sentimentData'
    load 'labels';
    At = data(1:20000,1:500);    
    bt = labels(1:20000);
    Ah = data(20001:25000,1:500);
    bh = labels(20001:25000);
    [m,n] = size(At);
    clear data;
    clear labels;
    % representative lambda values 
    lam_vals = [1e-6 1e-2 1e-1 1 3 5 7];
    N = numel(lam_vals);	    

    err = zeros( N,1);
    
    for i = 1:N 
        disp(i) 
        lambda = lam_vals(i); 
        x = iterative_landweber(At,bt,lambda); 
        b_predicted = (Ah*x);
        for i = 1:5000
            if b_predicted(i,:) <= 0
                b_predicted(i,:) = 0;
            else
                b_predicted(i,:) = 1;
            end
        end
        err(i) = norm(b_predicted - bh,1)/5000; 
        clear x;
    end
    disp('\n')
    disp(err)
end
 
function x = iterative_landweber( A, b, lambda ) 
    % this function solves the minimization problem 
    % Minimize |Ax-b|_2^2 + lambda*|x|_1 (Lasso regression) 
    
    MAX_ITER = 100; % maximum number of iterations 
    TOL = 1e-5; % convergence tolerance
    tau = 1/norm(A)^2; % choose stepsize
    [~,n] = size(A); 
    x = zeros(5000,1); % start point for the iteration
    for i = 1:MAX_ITER 
        z = x - tau*(A'*(A*x-b)); % Landweber 
        xold = x; % store old x
        clear x;
        x = sign(z) .* max( abs(z) - tau*lambda/2, 0 ); % ISTA
        clear z;
        if norm(x-xold) < TOL
            disp('here');
            break 
        end
        clear xold;
    end
end

