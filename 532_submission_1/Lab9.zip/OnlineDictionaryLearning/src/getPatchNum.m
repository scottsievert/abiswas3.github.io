function patchNum = getPatchNum(r, c, sm)
    nr=r-sm;nc=c-sm;
    patchNum=nr*nc;
end