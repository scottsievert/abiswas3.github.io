function M = create_doc_term_matrix( fileName,vocab,vocab_size,documents_number,stemming )
M=zeros(documents_number,vocab_size);
fid = fopen(fileName);
doc_i=0;
tline = fgetl(fid);
while ischar(tline)
    words=strsplit(tline);
    doc_i=doc_i+1;
    for iword = words
        if (stemming>0)    
            ilcword=stem(char(lower(iword)));
        else
            ilcword=(lower(iword));
        end
        index = find(strcmp(vocab, ilcword));
        % for ith document increas the occurence of the index-th word of
        % vocabulary
        M(doc_i,index)= M(doc_i,index)+1;
    end
    tline = fgetl(fid);
end
end

