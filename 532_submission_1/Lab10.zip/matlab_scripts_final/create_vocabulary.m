function [vocabulary vocab_size documents_number] = create_vocabulary( fileName, stopwords,stemming)
fid = fopen(fileName);
vocabulary=cell(0,1);
tline = fgetl(fid);
vocab_size=0;
documents_number=0;
while ischar(tline)
    words=strsplit(tline);
    for iword = words
        if (stemming>0)    
            ilcword=stem(char(lower(iword)));
        else
            ilcword=(lower(iword));
        end
        index = size(find(strcmp(vocabulary, ilcword)),1);
        stop= size(find(strcmp(stopwords, ilcword)),1);
        if ((index ==  0) && (stop == 0))
            vocab_size=vocab_size+1;
            vocabulary(vocab_size,1)=cellstr(ilcword);
        end
    end
    tline = fgetl(fid);
    documents_number=documents_number+1;
end


end

